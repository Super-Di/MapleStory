package com.neuedu.maplestory.entity;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.util.List;

import com.neuedu.maplestory.client.MapleStoryClient;
import com.neuedu.maplestory.constant.Constant;
import com.neuedu.maplestory.util.ImageUtil;
import com.neuedu.maplestory.util.MusicUtil;

/**
 * ð�յ��е�Ӣ������
 * 
 * @author С��
 * @version ����ʱ�䣺2019��8��17�� ����11:27:07
 */
public class Hero extends MapleStoryObject {
	/**
	 * ���������ͼƬ
	 */
	public static Image[] imgs = new Image[100];
	static {
		// ����
		for (int i = 0; i < 5; i++) {
			imgs[i] = ImageUtil.get("hero_walk_r" + i);
		}
		// ����
		for (int i = 5; i < 10; i++) {
			imgs[i] = ImageUtil.get("hero_walk_l" + (i - 5));
		}
		// �� ���
		for (int i = 10; i < 14; i++) {
			imgs[i] = ImageUtil.get("hero_shoot_r" + (i - 10));
		}
		// �� ���
		for (int i = 14; i < 18; i++) {
			imgs[i] = ImageUtil.get("hero_shoot_l" + (i - 14));
		}
	}
	/**
	 * ��ʾ�����ƶ������Boolean
	 */
	public boolean left, up, right, down, walk, jump, shoot, pick;

	/**
	 * ����ĳ�ʼ��
	 * 
	 * @param msc ��ͣ��
	 */
	public Hero(MapleStoryClient msc) {
		this.msc = msc;
		this.speed = Constant.HERO_SPEED;
		this.img = ImageUtil.get("hero_stand_r");
		this.width = img.getWidth(null);
		this.height = img.getHeight(null);
		this.dir = Direction.RIGHT;
		this.action = Action.STAND;
		this.x = 300;
		this.y = 510;
		this.HP = 1000;
		this.HP_FULL = this.HP;
	}

	/**
	 * ����������
	 * 
	 * @param x   x����
	 * @param y   y����
	 * @param msc ��ͣ��
	 */
	public Hero(int x, int y, MapleStoryClient msc) {
		this(msc);
		this.x = x;
		this.y = y;
	}

	/**
	 * ����������
	 * 
	 * @param x   x����
	 * @param y   y����
	 * @param img Ӣ�۵�image
	 * @param msc ��ͣ��
	 */
	public Hero(int x, int y, Image img, MapleStoryClient msc) {
		this(x, y, msc);
		this.img = img;
	}

	private int walk_r_count = 0;// [0,4]
	private int walk_l_count = 5;// [5,9]
	private int shoot_r_count = 10;// [10,13]
	private int shoot_l_count = 14;// [14,17]

	@Override
	public void draw(Graphics g) {

		// ���������ж�
		if (walk_r_count > 4) {
			walk_r_count = 0;
		}
		if (walk_l_count > 9) {
			walk_l_count = 5;
		}
		if (shoot_r_count > 13) {
			shoot_r_count = 10;
		}
		if (shoot_l_count > 17) {
			shoot_l_count = 14;
		}
		switch (dir) {
		case RIGHT:
			switch (action) {
			case STAND:
				g.drawImage(ImageUtil.get("hero_stand_r"), x, y, null);
				break;
			case WALK:
				g.drawImage(imgs[walk_r_count++], x, y, null);
				break;
			case JUMP:
				g.drawImage(ImageUtil.get("hero_jump_r"), x, y, null);
				break;
			case SHOOT:
				g.drawImage(imgs[shoot_r_count++], x, y, null);
				break;
			default:
				break;
			}
			break;
		case LEFT:
			switch (action) {
			case STAND:
				g.drawImage(ImageUtil.get("hero_stand_l"), x, y, null);
				break;
			case WALK:
				g.drawImage(imgs[walk_l_count++], x, y, null);
				break;
			case JUMP:
				g.drawImage(ImageUtil.get("hero_jump_l"), x, y, null);
				break;
			case SHOOT:
				g.drawImage(imgs[shoot_l_count++], x, y, null);
				break;
			default:
				break;
			}
			break;
		default:
			break;
		}
		if (shoot) {
			shoot();
		}
		// �жϷ���
		confirmDirection();
		if (jump) {
			jump();
		}
		if (walk) {
			move();
		}
		// �л�ͼƬ
		changeImage();
		// ��Ѫ��
		drawBloodBar(g);
		drawInfo(g);

	}

	/**
	 * �л�ͼƬ�ķ���
	 */
	public void changeImage() {
		if (walk) {
			this.action = Action.WALK;
			if (jump) {
				this.action = Action.JUMP;
				jump();
			}
		}
		// ԭ�����
		else if (shoot) {
			this.action = Action.SHOOT;
		}
		// ԭ����
		else if (jump) {
			this.action = Action.JUMP;
			jump();
		} else {
			this.action = Action.STAND;
		}
	}

	private void confirmDirection() {
		// �жϷ���
		if (left) {
			this.dir = Direction.LEFT;
		}
		if (right) {
			this.dir = Direction.RIGHT;
		}
	}

	@Override
	public void move() {
		if (left) {
			x -= speed;
		}
		if (up) {
			y -= speed;
		}
		if (right) {
			x += speed;
		}
		if (down) {
			y += speed;
		}
		outOfBound();
	}

	/**
	 * �߽��ж�
	 */
	private void outOfBound() {

		if (x <= 0) {
			x = 0;
		}
		if (x > Constant.GAME_WIDTH - width) {
			x = Constant.GAME_WIDTH - width;
		}
		if (y <= 0) {
			y = 0;
		}
		if (y > Constant.GAME_HEIGHT - height) {
			y = Constant.GAME_HEIGHT - height;
		}
	}

	/**
	 * ���������ƶ�
	 * 
	 * @param e �����¼�
	 */
	public void keyPressed(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_A:
			left = true;
			walk = true;
			break;
		case KeyEvent.VK_D:
			right = true;
			walk = true;
			break;
		case KeyEvent.VK_W:
			up = true;
			break;
		case KeyEvent.VK_S:
			down = true;
			break;
		case KeyEvent.VK_K:
			jump = true;
			break;
		// ���
		case KeyEvent.VK_J:
			shoot = true;
			break;
		// ʰȡ����
		case KeyEvent.VK_L:
			pick = true;
			break;
		default:
			break;
		}
	}

	/**
	 * ̧���
	 * 
	 * @param e �����¼�
	 */
	public void keyReleased(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_A:
			left = false;
			walk = false;
			break;
		case KeyEvent.VK_D:
			right = false;
			walk = false;
			break;
		case KeyEvent.VK_W:
			up = false;
			break;
		case KeyEvent.VK_S:
			down = false;
			break;
		case KeyEvent.VK_J:
			shoot = false;
			break;
		case KeyEvent.VK_L:
			pick = false;
			break;
		default:
			break;
		}

	}

	private double v0 = 50;
	private double vt = 0;
	private double delta_h = 0;
	private static final double g = 9.8;
	private double t = 1;
	private boolean jump_up = true; // Ĭ������

	/**
	 * �����㷨
	 */
	public void jump() {
		if (jump_up) {
			// ��ֱ����
			vt = v0 - g * t;
			v0 = vt;
			delta_h = v0 * t;
			y -= delta_h;
			if (vt <= 0) {
				v0 = 0;
				vt = 0;
				jump_up = false;
			}
		} else {
			// ��������
			vt = v0 + g * t;
			v0 = vt;
			delta_h = v0 * t;
			y += delta_h;
//			 ������������
			if (y > 500) {
				y = 500;
				jump_up = true;
				// �´����׵��ٶ�
				v0 = 50;
				vt = 0;
				jump = false;
				this.action = Action.STAND;
			}
			if (x < 1070 && x > 995 && y > 450) {
				y = 450;
				jump_up = true;
				// �´����׵��ٶ�
				v0 = 50;
				vt = 0;
				jump = false;
				this.action = Action.STAND;
			}

			if (x < 980 && x > 750 && y > 400) {
				y = 340;
				jump_up = true;
				// �´����׵��ٶ�
				v0 = 50;
				vt = 0;
				jump = false;
				this.action = Action.STAND;
			}

		}
	}

	/**
	 * Ӣ������ķ���
	 */
	public void shoot() {
		new MusicUtil("com/neuedu/maplestory/sounds/02.mp3").start();
		Arrow arrow = null;
		switch (dir) {
		case LEFT:
			arrow = new Arrow(msc, this.x - width / 2, this.y + height / 2, this.dir);
			break;
		case RIGHT:
			arrow = new Arrow(msc, this.x + width / 2, this.y + height / 2, this.dir);
			break;
		default:
			break;
		}
		msc.arrows.add(arrow);
	}

	/**
	 * Ӣ�۳Ե���
	 * 
	 * @param item ����
	 * @return �Ƿ�Ե�����
	 */
	public boolean eatItem(Item item) {
		if (item.live && this.getRectangle().intersects(item.getRectangle())) {
			// �Ե���
			if (pick) {
				switch (item.itemType) {
				case 0:
					this.HP += 50;
					if (this.HP >= this.HP_FULL) {
						this.HP = this.HP_FULL;
					}
					break;
				case 1:
					this.HP += 150;
					if (this.HP >= this.HP_FULL) {
						this.HP = this.HP_FULL;
					}
					break;
				case 2:
					this.HP += 300;
					if (this.HP >= this.HP_FULL) {
						this.HP = this.HP_FULL;
					}
					break;
				case 3:
					this.HP += (int) (HP_FULL * 0.5);
					if (this.HP >= this.HP_FULL) {
						this.HP = this.HP_FULL;
					}
					break;
				case 4:
					this.HP += HP_FULL;
					if (this.HP >= this.HP_FULL) {
						this.HP = this.HP_FULL;
					}
					break;
				default:
					break;
				}

				msc.items.remove(item);
			}

			return true;
		}
		return false;
	}

	/**
	 * ��һ�ѵ���
	 * 
	 * @param items һ�ѵ���
	 * @return �Ƿ�Ե�
	 */
	public boolean eatItem(List<Item> items) {
		for (int i = 0; i < items.size(); i++) {
			Item item = items.get(i);
			if (eatItem(item)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * ��Ѫ��
	 * 
	 * @param g
	 */
	private void drawBloodBar(Graphics g) {
		for (int i = 0; i < (this.width / 2) * HP / 230; i++) {
			BloodBar bb = new BloodBar(this.x + i, this.y - 12);
			bb.draw(g);
		}
	}
	/**
	 * ��Ա�ڲ��ࣺ����ֱ�ӷ����ⲿ����������Ժͷ���
	 */
	class BloodBar {
		int x;
		int y;
		Image img;

		public BloodBar() {

		}

		public BloodBar(int x, int y) {
			this.x = x;
			this.y = y;

		}

		public void draw(Graphics g) {
			double p = (double)HP / HP_FULL;
			if (p >= 0.8 && p <= 1) {
				g.drawImage(ImageUtil.get("b_div2"), x, y, null);
			} else if (p >= 0.5 && p < 0.8) {
				g.drawImage(ImageUtil.get("b_div3"), x, y, null);
			} else if (p > 0 && p < 0.5) {
				g.drawImage(ImageUtil.get("b_div"), x, y, null);
			}
		}
	}

	/**
	 * Ӣ�۵�����
	 * 
	 * @param g ����
	 */
	public void drawInfo(Graphics g) {
		int x = this.x;
		int y = this.y + 100;
		Font f = g.getFont();
		Color c = g.getColor();
		g.setColor(Color.WHITE);
		g.setColor(Color.ORANGE);
		g.drawString("lv" + 1 + "    " + "ƤƤ", x, y);
		g.setFont(new Font("΢���ź�", Font.BOLD, 16));
		g.setFont(f);
		g.setColor(c);
	}

}
