package com.neuedu.maplestory.entity;

import java.awt.Graphics;

import com.neuedu.maplestory.client.MapleStoryClient;
import com.neuedu.maplestory.constant.Constant;
import com.neuedu.maplestory.util.ImageUtil;

/**
 * ������װ��
 * 
 * @author С��
 * @version ����ʱ�䣺2019��8��21�� ����4:39:03
 */
public class Item extends MapleStoryObject {
	/**
	 * ���ߵ�����
	 */
	public int itemType;

	/**
	 * �޲ι���
	 */
	public Item() {

	}

	/**
	 * item�ĳ�ʼ��
	 * 
	 * @param msc      ��ͣ��
	 * @param x        x����
	 * @param y        y����
	 * @param itemType ��������
	 */
	public Item(MapleStoryClient msc, int x, int y, int itemType) {
		this.msc = msc;
		this.x = x;
		this.y = y+200;
		switch (itemType) {
		case 0:
			this.img = ImageUtil.get("item01");
			break;
		case 1:
			this.img = ImageUtil.get("item02");
			break;
		case 2:
			this.img = ImageUtil.get("item03");
			break;
		case 3:
			this.img = ImageUtil.get("item04");
			break;
		case 4:
			this.img = ImageUtil.get("item05");
			break;

		default:
			break;
		}
		this.width = img.getWidth(null);
		this.height = img.getHeight(null);
		this.itemType = itemType;
	}

	@Override
	public void draw(Graphics g) {
		g.drawImage(img, x, y, null);
		move();
	}

	@Override
	public void move() {
		if (jump) {
			jump();
		}
	}

	private double v0 = Constant.HERO_JUMP_SPEED;
	private double vt = 0;
	private double delta_h = 0;
	private static final double g = 9.8;
	private double t = 1;
	private boolean jump_up = true; // Ĭ������
	private boolean jump = true;

	/**
	 * �����㷨
	 */
	public void jump() {
		if (jump_up) {
			// ��ֱ����
			vt = v0 - g * t;
			v0 = vt;
			delta_h = v0 * t;
			y -= delta_h;
			if (vt <= 0) {
				v0 = 0;
				vt = 0;
				jump_up = false;
			}
		} else {
			// ��������
			vt = v0 + g * t;
			v0 = vt;
			delta_h = v0 * t;
			y += delta_h;
			// ������������
			if (y > 570) {
				y = 570;
				jump_up = true;
				// �´����׵��ٶ�
				v0 = Constant.HERO_JUMP_SPEED;
				vt = 0;
				jump = false;
			}
		}
	}

}
