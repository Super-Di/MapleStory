package com.neuedu.maplestory.entity;

import java.awt.Graphics;

import com.neuedu.maplestory.util.ImageUtil;

/**
 * ����ͼƬ
 * 
 * @author С��
 * @version ����ʱ�䣺2019��8��21�� ����7:46:45
 */
public class BackGround extends MapleStoryObject {
	/**
	 * �޲ι���
	 */
	public BackGround() {
		this.x = 0;
		this.y = 0;
		this.img = ImageUtil.get("bcg");
		this.width=img.getWidth(null);
	}

	@Override
	public void draw(Graphics g) {
		g.drawImage(img, 0, 0, null);
	}

	@Override
	public void move() {
	
	}

}
