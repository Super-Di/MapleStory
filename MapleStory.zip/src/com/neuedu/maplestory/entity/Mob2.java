package com.neuedu.maplestory.entity;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

import com.neuedu.maplestory.client.MapleStoryClient;
import com.neuedu.maplestory.constant.Constant;
import com.neuedu.maplestory.util.ImageUtil;

/**
 * ���������
 * 
 * @author С��
 * @version ����ʱ�䣺2019��8��22�� ����11:49:09
 */
public class Mob2 extends Mob {

	/**
	 * �ж�2�Ź����Ƿ񹥻�
	 */

	public static Image[] imgs = new Image[100];
	/**
	 * Mob
	 */
	static {

		// stand left
		for (int i = 0; i < 6; i++) {
			imgs[i] = ImageUtil.get("mob2_stand_l" + i);
		}
		// ����
		for (int i = 6; i < 12; i++) {
			imgs[i] = ImageUtil.get("mob2_walk_r" + (i - 6));
		}
		// ����
		for (int i = 12; i < 18; i++) {
			imgs[i] = ImageUtil.get("mob2_walk_l" + (i - 12));
		}
		// stand right
		for (int i = 18; i < 24; i++) {
			imgs[i] = ImageUtil.get("mob2_stand_r" + (i - 18));
		}
		// die right
		for (int i = 24; i < 34; i++) {
			imgs[i] = ImageUtil.get("mob2_die_r" + (i - 24));
		}
		// left
		for (int i = 34; i < 44; i++) {
			imgs[i] = ImageUtil.get("mob2_die_l" + (i - 34));
		}
		// attack right
		for (int i = 44; i < 56; i++) {
			imgs[i] = ImageUtil.get("mob2_attack_r" + (i - 44));
		}
		// left
		for (int i = 56; i < 68; i++) {
			imgs[i] = ImageUtil.get("mob2_attack_l" + (i - 56));
		}
	}

	/**
	 * �޲ι���
	 */
	public Mob2() {

	}

	/**
	 * ����ս��Ȯ�ĳ�ʼ��
	 * 
	 * @param msc        ��ͣ��
	 * @param x          x����
	 * @param y          y����
	 * @param actionType ������̬
	 */

	public Mob2(MapleStoryClient msc, int x, int y, int actionType) {
		this.name = "���������";
		this.msc = msc;
		this.x = x;
		this.y = y;

		switch (actionType) {
		case 0:
			this.dir = Direction.LEFT;
			this.action = Action.WALK;
			break;
		case 1:
			this.dir = Direction.LEFT;
			this.action = Action.STAND;
			break;

		case 2:
			this.dir = Direction.RIGHT;
			this.action = Action.WALK;
			break;

		case 3:
			this.dir = Direction.RIGHT;
			this.action = Action.STAND;
			break;

		default:
			break;
		}
		this.width = imgs[0].getWidth(null);
		this.height = imgs[0].getHeight(null);
		this.HP = 100;
		this.HP_FULL = this.HP;
		this.speed = 5;
	}

	private int stand_left_count = 0;
	private int walk_right_count = 6;
	private int walk_left_count = 12;
	private int stand_right_count = 18;
	private int die_right_count = 24;
	private int die_left_count = 34;
	private int attack_right_count = 44;
	private int attack_left_count = 56;

//	private int rate_count = 0;

	@Override
	public void draw(Graphics g) {
//		rate_count++;
		if (stand_left_count >= 5) {
			stand_left_count = 0;
		}
		if (walk_right_count >= 12) {
			walk_right_count = 7;
		}
		if (walk_left_count >= 17) {
			walk_left_count = 13;
		}
		if (stand_right_count >= 24) {
			stand_right_count = 19;
		}
		if (die_right_count >= 35) {
			die_right_count = 25;
			live = false;
			msc.mobs.remove(this);
		}
		if (die_left_count >= 45) {
			die_left_count = 35;
			live = false;
			msc.mobs.remove(this);
		}
		if (attack_right_count > 56) {
			attack_right_count = 45;
		}
		if (attack_left_count > 67) {
			attack_left_count = 56;
		}
		switch (dir) {
		case LEFT:
			switch (action) {
			case STAND:
				g.drawImage(imgs[stand_left_count++], x, y, null);
				break;
			case WALK:
				g.drawImage(imgs[walk_left_count++], x, y, null);
				break;
			case ATTACK:
				g.drawImage(imgs[attack_left_count++], x, y, null);
				break;
			case DIE:
				if (live) {
					g.drawImage(imgs[die_left_count++], x, y, null);
				}
				break;

			default:
				break;
			}
			break;
		case RIGHT:
			switch (action) {
			case STAND:
//				if (rate_count >= 10) {
//					rate_count = 0;
				g.drawImage(imgs[stand_right_count++], x, y, null);
//				} else {
//					g.drawImage(imgs[stand_right_count], x, y, null);

//				}
				break;
			case WALK:
				g.drawImage(imgs[walk_right_count++], x, y, null);
				break;
			case ATTACK:
				g.drawImage(imgs[attack_right_count++], x, y, null);
				break;
			case DIE:
				if (live) {
					g.drawImage(imgs[die_right_count++], x, y, null);
				}
				break;
			default:
				break;
			}
			break;
		default:
			break;
		}
		move();
		drawBloodBar(g);
		drawInfo(g);

	}

	/**
	 * �������
	 */
	public void attack() {
		if (this.live && this.getRectangle().intersects(msc.hero.getRectangle())) {
			this.action = Action.ATTACK;

			if (this.dir == Direction.LEFT && msc.hero.x > this.x) {
				this.dir = Direction.RIGHT;
			} else if (this.dir == Direction.RIGHT && msc.hero.x < this.x ) {
				this.dir = Direction.LEFT;
			}
			msc.hero.HP -= 5;
			if (msc.hero.HP  <= 0) {
				msc.hero.HP  = 0;
			}
		} else {
			this.action = Action.WALK;
		}
	}

	/**
	 * ��������
	 * 
	 * @param g  ����
	 */
	public void drawInfo(Graphics g) {
		int x = this.x;
		int y = this.y + this.height + 12;
		Color c = g.getColor();
		Font f = g.getFont();
		g.setColor(Color.magenta);
		g.drawString("lv." + level + " " + name, this.x, y);
		g.setFont(new Font("΢���ź�", Font.PLAIN, 30));
		g.setColor(new Color(0.3f, 0.3f, 0.3f, 0.7f));
		g.fillRect(x, y - 10, 88, 15);
		g.setColor(c);
		g.setFont(f);

	}

	@Override
	public void move() {
		switch (dir) {
		case LEFT:
			switch (action) {
			case WALK:
				this.x -= speed;
				break;
			default:
				break;
			}
			break;
		case RIGHT:
			switch (action) {
			case WALK:
				this.x += speed;
				break;
			default:
				break;
			}
			break;

		default:
			break;
		}
		outOfBound();
		attack();
	}

	/**
	 * �߽��ж�
	 */
	private void outOfBound() {

		if (x <= 0) {
			this.dir = Direction.RIGHT;
		}
		if (x > Constant.GAME_WIDTH - width) {
			this.dir = Direction.LEFT;
		}
	}

	/**
	 * ��Ѫ��
	 * 
	 * @param g
	 */
	private void drawBloodBar(Graphics g) {
		for (int i = 0; i < (this.width / 2) * HP / 100; i++) {
			BloodBar bb = new BloodBar(this.x + (i * 2), this.y - 16);
			bb.draw(g);
		}
	}

	/**
	 * ��Ա�ڲ��ࣺ����ֱ�ӷ����ⲿ����������Ժͷ���
	 */
	class BloodBar {
		int x;
		int y;
		Image img;

		public BloodBar() {

		}

		public BloodBar(int x, int y) {
			this.x = x;
			this.y = y;
			this.img = ImageUtil.get("b_div3");

		}

		public void draw(Graphics g) {
			g.drawImage(img, x, y, null);
		}
	}

}
