package com.neuedu.maplestory.util;
/**
 * ��Ŀ������ͼƬ����
 * @author С��
 * @version ����ʱ�䣺2019��8��16�� ����3:17:41
 */

import java.awt.Image;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

import com.neuedu.maplestory.constant.Constant;

public class ImageUtil {
	/**
	 * �����Ŀ������ͼƬ�ļ�-ֵ��
	 */
	private static Map<String, Image> imgs = new HashMap<>();
	/**
	 * ��̬��ʼ��
	 */
	static {
		// ����ͼ
		imgs.put("bcg", ImageUtil.getImage("bcg/bcg1"));
		imgs.put("bcg1", ImageUtil.getImage("bcg/bcg2"));
		// icon
		imgs.put("icon", ImageUtil.getImage("icon/icon"));
		// hero blood
		imgs.put("b_div2", ImageUtil.getImage("hero/blood/b"));
		// hero stand
		imgs.put("hero_stand_r", ImageUtil.getImage("hero/stand/right/alert_0"));
		imgs.put("hero_stand_l", ImageUtil.getImage("hero/stand/left/alert_0"));
		// hero walk
		// right
		for (int i = 0; i < 5; i++) {

			imgs.put("hero_walk_r" + i, ImageUtil.getImage("hero/walk/right/walk1_" + i));
		}
		// left
		for (int i = 5; i < 10; i++) {

			imgs.put("hero_walk_l" + (i - 5), ImageUtil.getImage("hero/walk/left/walk1_" + (i - 5)));

		}
		// hero fly
		for (int i = 0; i < 3; i++) {
			imgs.put("hero_fly_r" + i, ImageUtil.getImage("hero/fly/" + i));

		}
		// hero jump
		// right
		imgs.put("hero_jump_r", ImageUtil.getImage("hero/jump/right/jump_0"));
		// left
		imgs.put("hero_jump_l", ImageUtil.getImage("hero/jump/left/jump_0"));
		// hero shoot
		// right
		for (int i = 0; i < 4; i++) {

			imgs.put("hero_shoot_r" + i, ImageUtil.getImage("hero/shoot/right/shoot1_" + i));
		}
		// left
		for (int i = 0; i < 4; i++) {

			imgs.put("hero_shoot_l" + i, ImageUtil.getImage("hero/shoot/left/shoot1_" + i));
		}
		// bullet right
		imgs.put("bullet_Arrow_r", ImageUtil.getImage("bullet/Arrow/right/shoot_r"));
		// left
		imgs.put("bullet_Arrow_l", ImageUtil.getImage("bullet/Arrow/left/shoot_l"));

		// Mob
		// Mob1()
		// left
		for (int i = 0; i < 6; i++) {
			imgs.put("mob_mob1_stand_l" + i, ImageUtil.getImage("mobs/mob1/stand/left/mob_" + i));
		}
		// right
		for (int i = 0; i < 6; i++) {
			imgs.put("mob_mob1_stand_r" + i, ImageUtil.getImage("mobs/mob1/stand/right/" + i));
		}
		// �����Ѫ��
		imgs.put("b_div", ImageUtil.getImage("mobs/mob1/blooddiv/blood"));
		// ����walk
		// right
		for (int i = 0; i < 6; i++) {
			imgs.put("mob_mob1_walk_r" + i, ImageUtil.getImage("mobs/mob1/walk/right/" + i));
		}
		// left
		for (int i = 0; i < 6; i++) {
			imgs.put("mob_mob1_walk_l" + i, ImageUtil.getImage("mobs/mob1/walk/left/" + i));
		}
		// ���� die
		// right
		for (int i = 0; i < 12; i++) {
			imgs.put("mob_mob1_die_r" + i, ImageUtil.getImage("mobs/mob1/die/right/" + i));
		}
		// left
		for (int i = 0; i < 12; i++) {
			imgs.put("mob_mob1_die_l" + i, ImageUtil.getImage("mobs/mob1/die/left/" + i));
		}
		// item
		imgs.put("item01", ImageUtil.getImage("items/01"));
		imgs.put("item02", ImageUtil.getImage("items/02"));
		imgs.put("item03", ImageUtil.getImage("items/03"));
		imgs.put("item04", ImageUtil.getImage("items/04"));
		imgs.put("item05", ImageUtil.getImage("items/05"));
		// Mob2
		// blood
		imgs.put("b_div3", ImageUtil.getImage("mobs/mob2/blooddiv/b2"));
		// stand left
		for (int i = 0; i < 6; i++) {
			imgs.put("mob2_stand_l" + i, ImageUtil.getImage("mobs/mob2/stand/left/" + i));

		}
		// stand right
		for (int i = 0; i < 6; i++) {
			imgs.put("mob2_stand_r" + i, ImageUtil.getImage("mobs/mob2/stand/right/" + i));
		}
		// walk right
		for (int i = 0; i < 6; i++) {
			imgs.put("mob2_walk_r" + i, ImageUtil.getImage("mobs/mob2/walk/right/" + i));
		}
		// walk left
		for (int i = 0; i < 6; i++) {
			imgs.put("mob2_walk_l" + i, ImageUtil.getImage("mobs/mob2/walk/left/" + i));
		}
		// die right
		for (int i = 0; i < 10; i++) {
			imgs.put("mob2_die_r" + i, ImageUtil.getImage("mobs/mob2/die/right/" + i));
		}
		// die left
		for (int i = 0; i < 10; i++) {
			imgs.put("mob2_die_l" + i, ImageUtil.getImage("mobs/mob2/die/left/" + i));
		}
		// attack right
		for (int i = 0; i < 12; i++) {
			imgs.put("mob2_attack_r" + i, ImageUtil.getImage("mobs/mob2/attack/right/" + i));
		}
		// attack left
		for (int i = 0; i < 12; i++) {
			imgs.put("mob2_attack_l" + i, ImageUtil.getImage("mobs/mob2/attack/left/" + i));
		}

	}

	/**
	 * �õ�ͼƬ�ķ���ֵ
	 * 
	 * @param imgName
	 * @return image
	 */
	private static Image getImage(String imgName) {
		URL u = Constant.class.getClassLoader().getResource(Constant.IMG_PRE + imgName + ".png");
		Image img = null;
		try {
			img = ImageIO.read(u);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return img;
	}

	/**
	 * ��map�л�ȡͼƬ����
	 * 
	 * @param key	key
	 * @return ͼƬ����
	 */
	public static Image get(String key) {
		return imgs.get(key);
	}
}
