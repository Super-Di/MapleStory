package com.neuedu.maplestory.constant;

import java.io.IOException;

import java.util.Properties;

/**
 * ��Ŀ�����еĳ���
 * 
 * @author С��
 * @version ����ʱ�䣺2019��8��16�� ����3:20:20
 */
public final class Constant {
	private static Properties props = new Properties();
	static {
		try {
			props.load(Constant.class.getClassLoader()
					.getResourceAsStream("maplestory.propertise"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * ���峣��
	 */
	public static final int GAME_WIDTH = getProperty("GAME_WIDTH");
	public static final int GAME_HEIGHT = getProperty("GAME_HEIGHT");
	/**
	 * ͼƬ����ǰ׺
	 */
	public static final String IMG_PRE = props.getProperty("IMG_PRE");
	public static final int HERO_SPEED = getProperty("HERO_SPEED");
	public static final int HERO_JUMP_SPEED = getProperty("HERO_JUMP_SPEED");

	/**
	 * �õ�һ��int���͵ķ���ֵ
	 * 
	 * @param key key
	 * @return key
	 */
	public static int getProperty(String key) {
		return Integer.parseInt(props.getProperty(key));
	}

}
