package com.neuedu.maplestory.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * 
 * @author С��
 * @version ����ʱ�䣺2019��8��26�� ����9:11:40
 */
public class RandomTest {
	public static void main(String[] args) {
		List<Integer> list1 = new ArrayList<Integer>();
		List<Integer> list2 = new ArrayList<Integer>();
		Random r = new Random();
		for (int i = 1; i < 59; i++) {
			list1.add(i);
		}
		Iterator<Integer> its = list1.iterator();
		while(its.hasNext()) {
			 its.next();
			System.out.println(list1);
		}
//		System.out.println(list1);
		for (int i = 0; i < 15; i++) {
			int rIndex = r.nextInt(list1.size());
			int random = list1.get(rIndex);
			list2.add(random);
			list1.remove(rIndex);
		}
		Collections.sort(list2);
		System.out.println(list2);
	}
		
//			static boolean foo(char c) {
//				System.out.print(c);
//				return true;
//			}
//			public static void main(String[] args) {
//		 		int i = 0;
//				for (foo('A'); foo('B') && (i < 2); foo('C')) {
//					i++;
//		            foo('D');
//		        }
//		    }

}
