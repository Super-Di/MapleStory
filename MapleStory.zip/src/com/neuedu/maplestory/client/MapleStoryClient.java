package com.neuedu.maplestory.client;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.neuedu.maplestory.entity.Arrow;
import com.neuedu.maplestory.entity.BackGround;
import com.neuedu.maplestory.entity.Hero;
import com.neuedu.maplestory.entity.Item;
import com.neuedu.maplestory.entity.Mob;
import com.neuedu.maplestory.entity.Mob1;
import com.neuedu.maplestory.entity.Mob2;
import com.neuedu.maplestory.util.ImageUtil;
import com.neuedu.maplestory.util.MusicUtil;
import com.neuedu.maplestory.util.MyFrame;

/**
 * ð�յ��ͻ���
 * 
 * @author С��
 * @version ����ʱ�䣺2019��8��16�� ����3:14:03
 */
public class MapleStoryClient extends MyFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = -203171016399730275L;

	/**
	 * ��Ź���������
	 */
	public List<Arrow> arrows = new ArrayList<>();
	/**
	 * ��ű�Ʒ������
	 */
	public List<Item> items = new ArrayList<>();
	/**
	 * ����hero����
	 */
	public Hero hero = new Hero(this);
	/**
	 * ������������
	 */
	public BackGround bcg = new BackGround();
	/**
	 * ��Ź��������
	 */
	public List<Mob> mobs = new ArrayList<>();
	/**
	 * Mob1
	 */
	{
		for (int i = 0; i < 3; i++) {
			int random = new Random().nextInt(4);
			Mob mob = new Mob1(this, 500 + (i * 100), 520, random);
			mobs.add(mob);
		}
	}
	/**
	 * Mob2
	 */
	{
		for (int i = 0; i < 3; i++) {
			int random = new Random().nextInt(4);
			Mob mob = new Mob2(this, 350 + (i * 200), 450, random);
			mobs.add(mob);
		}
	}

	@Override
	public void paint(Graphics g) {
		bcg.draw(g);
		if(hero.HP>0) {
			hero.draw(g);			
		}
		// �� �ӵ�
		for (int i = 0; i < arrows.size(); i++) {
			Arrow arrow = arrows.get(i);
			arrow.draw(g);
			arrow.hit(mobs);
		}
		// ��Mob
		for (int i = 0; i < mobs.size(); i++) {
			Mob mob = mobs.get(i);
			mob.draw(g);
		}

		// ��������
		for (int i = 0; i < items.size(); i++) {
			Item item = items.get(i);
			item.draw(g);	
		}
		// �Ե���
		hero.eatItem(items);
		Font f = g.getFont();
		Color c = g.getColor();
		g.setColor(Color.RED);
		g.setFont(new Font("΢���ź�", Font.BOLD, 20));
		g.drawString("Ӣ�۵�ǰ��Ѫ��ֵΪ��  " + hero.HP+"/" +hero.HP_FULL, 50, 100);
		g.setFont(f);
		g.setColor(c);
	}

	@Override
	public void loadFrame() {
		super.loadFrame();
		this.setIconImage(ImageUtil.get("icon"));
		// ���̼���
		this.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				hero.keyPressed(e);
			}

			@Override
			public void keyReleased(KeyEvent e) {
				hero.keyReleased(e);
			}
		});
		new MusicUtil("com/neuedu/maplestory/sounds/01.mp3", true).start();
	}

	/**
	 * ����������
	 * 
	 * @param args	������
	 */
	public static void main(String[] args) {
		new MapleStoryClient().loadFrame();
	}

}
